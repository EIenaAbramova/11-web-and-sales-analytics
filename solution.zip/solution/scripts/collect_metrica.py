"""Collect public demo data. No OAuth token or personal account is used."""
import csv
import json
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import urlopen
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'data' / 'metrica'
OUT.mkdir(parents=True, exist_ok=True)
METRICS = 'ym:s:users,ym:s:newUsers,ym:s:visits,ym:s:pageviews,ym:s:pageDepth,ym:s:avgVisitDurationSeconds,ym:s:bounceRate'
BASE = dict(id='44147844', date1='2024-06-01', date2='2024-06-30', accuracy='full', lang='en', limit='10000', metrics=METRICS)
JOBS = {
 'summary': {},
 'countries': {'dimensions': 'ym:s:regionCountry'},
 'russia': {'filters': "ym:s:regionCountry=='225'"},
 'russian_regions': {'dimensions': 'ym:s:regionArea', 'filters': "ym:s:regionCountry=='225'"},
 'minsk': {'dimensions':'ym:s:regionCountry,ym:s:regionCity','filters': "ym:s:regionCityName=='Minsk' AND ym:s:regionCountry=='149'"},
 'browsers': {'dimensions':'ym:s:browser'},
 'browser_versions': {'dimensions':'ym:s:browser,ym:s:browserAndVersion'},
 'russian_browser_versions': {'dimensions':'ym:s:browser,ym:s:browserAndVersion,ym:s:regionArea','filters':"ym:s:regionCountry=='225'"},
 'devices': {'dimensions':'ym:s:deviceCategory'},
 'mobile_models': {'dimensions':'ym:s:mobilePhoneModel','filters':"ym:s:deviceCategory=='mobile'"},
 'mobile_brands': {'dimensions':'ym:s:mobilePhone','filters':"ym:s:deviceCategory=='mobile'"},
 'search_total': {'filters':"ym:s:lastTrafficSource=='organic'"},
 'search_engines': {'dimensions':'ym:s:lastSearchEngineRoot','filters':"ym:s:lastTrafficSource=='organic'"},
 'pages_desktop': {'dimensions':'ym:pv:URLPathFull','metrics':'ym:pv:pageviews','filters':"ym:pv:deviceCategory=='desktop'", 'sort':'-ym:pv:pageviews', 'limit':'10'},
 'pages_mobile': {'dimensions':'ym:pv:URLPathFull','metrics':'ym:pv:pageviews','filters':"ym:pv:deviceCategory=='mobile'", 'sort':'-ym:pv:pageviews', 'limit':'10'},
}

def collect(job):
    name, extra = job
    url = 'https://api-metrika.yandex.net/stat/v1/data?' + urlencode(BASE | extra)
    record = {'name':name, 'url':url,'retrieved_at_utc':datetime.now(timezone.utc).isoformat()}
    try:
        with urlopen(url, timeout=75) as response:
            body = json.load(response)
        (OUT / (name+'.json')).write_text(json.dumps(body,ensure_ascii=False,indent=2),encoding='utf-8')
        dims=body['query']['dimensions']; metrics=body['query']['metrics']
        with (OUT/(name+'.csv')).open('w',encoding='utf-8-sig',newline='') as f:
            writer=csv.writer(f); writer.writerow(dims+metrics)
            for row in body['data']:
                writer.writerow([x.get('name','') if x else '' for x in row['dimensions']]+row['metrics'])
        record.update(status='ok', rows=body['total_rows'], sampled=body.get('sampled'), sample_share=body.get('sample_share'))
        print(name, record['rows'], body['totals'], flush=True)
    except Exception as exc:
        record.update(status='error',error=str(exc))
        if hasattr(exc,'read'): record['error_body']=exc.read().decode('utf-8')
        print(name, record, flush=True)
    return record

if __name__=='__main__':
    with ThreadPoolExecutor(max_workers=3) as pool:
        log=list(pool.map(collect,JOBS.items()))
    (OUT/'manifest.json').write_text(json.dumps(log,ensure_ascii=False,indent=2),encoding='utf-8')
