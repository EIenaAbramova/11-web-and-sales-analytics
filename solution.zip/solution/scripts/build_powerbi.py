"""Generate a portable PBIP model and matrix from the twelve assignment rows."""
import csv
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'powerbi'
OUT.mkdir(exist_ok=True)
values=[[1200,800,500],[1500,600,700],[1000,1100,900],[250,2000,450]]
rows=[(f'2024-12-{d:02}',f'Категория {c}',values[d-1][c-1]) for d in range(1,5) for c in range(1,4)]
with (OUT/'sales.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['Дата','Категория','Продажи']);w.writerows(rows)

def save(path,obj):
 p=OUT/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
def literal(value): return {'expr':{'Literal':{'Value':value}}}
def color(value): return {'solid':{'color':literal("'"+value+"'")}}
def field(prop,kind='Column'):return {kind:{'Expression':{'SourceRef':{'Entity':'Продажи'}},'Property':prop}}
def projection(prop,kind='Column'):return {'field':field(prop,kind),'queryRef':'Продажи.'+prop,'nativeQueryRef':prop}

mrows=',\n'.join('        {#date(2024,12,%d), "%s", %d, %d}'%(int(date[-2:]),cat,sale,-int(date.replace('-',''))) for date,cat,sale in rows)
m='let\n    Source = #table(type table [Дата=date, Категория=text, Продажи=Int64.Type, ПорядокДаты=Int64.Type], {\n'+mrows+'\n    })\nin\n    Source'
(OUT/'source.pq').write_text(m,encoding='utf-8')
cols=[{'name':name,'dataType':dtype,'sourceColumn':name,'summarizeBy':summ} for name,dtype,summ in [('Дата','dateTime','none'),('Категория','string','none'),('Продажи','int64','sum'),('ПорядокДаты','int64','none')]]
cols[0].update(formatString='dd.MM.yyyy',sortByColumn='ПорядокДаты',annotations=[{'name':'UnderlyingDateTimeDataType','value':'Date'}])
cols[2]['formatString']='#,0';cols[3]['isHidden']=True
save(Path('Sales.SemanticModel/model.bim'),{'compatibilityLevel':1606,'model':{'culture':'ru-RU','sourceQueryCulture':'ru-RU','defaultPowerBIDataSourceVersion':'powerBI_V3','annotations':[{'name':'PBI_QueryOrder','value':'["Продажи"]'}],'tables':[{'name':'Продажи','columns':cols,'measures':[{'name':'Сумма продаж','expression':"SUM('Продажи'[Продажи])",'formatString':'#,0'},{'name':'Цвет ячейки','expression':'SWITCH(TRUE(), [Сумма продаж] >= 1500, "#B8D9EF", [Сумма продаж] >= 1000, "#E4EFF7", "#F3F6FA")','isHidden':True}],'partitions':[{'name':'Продажи','mode':'import','source':{'type':'m','expression':m.splitlines()}}]}]}})
save(Path('Sales.SemanticModel/definition.pbism'),{'version':'4.2','settings':{}})
save(Path('Sales.pbip'),{'version':'1.0','artifacts':[{'report':{'path':'Sales.Report'}}],'settings':{'enableAutoRecovery':True}})
save(Path('Sales.Report/definition.pbir'),{'version':'4.0','datasetReference':{'byPath':{'path':'../Sales.SemanticModel'}}})
save(Path('Sales.Report/definition/version.json'),{'$schema':'https://developer.microsoft.com/json-schemas/fabric/item/report/definition/versionMetadata/1.0.0/schema.json','version':'2.0.0'})
theme_source=Path(__file__).resolve().parent/'assets/CY24SU10.json'
theme_target=OUT/'Sales.Report/StaticResources/SharedResources/BaseThemes/CY24SU10.json'
if not theme_target.exists():
 theme_target.parent.mkdir(parents=True,exist_ok=True)
 theme_target.write_bytes(theme_source.read_bytes())
save(Path('Sales.Report/definition/report.json'),{'$schema':'https://developer.microsoft.com/json-schemas/fabric/item/report/definition/report/3.3.0/schema.json','themeCollection':{'baseTheme':{'name':'CY24SU10','reportVersionAtImport':{'visual':'1.8.97','report':'2.0.97','page':'1.3.97'},'type':'SharedResources'}},'resourcePackages':[{'name':'SharedResources','type':'SharedResources','items':[{'name':'CY24SU10','path':'BaseThemes/CY24SU10.json','type':'BaseTheme'}]}],'settings':{'useStylableVisualContainerHeader':True}})
save(Path('Sales.Report/definition/pages/pages.json'),{'$schema':'https://developer.microsoft.com/json-schemas/fabric/item/report/definition/pagesMetadata/1.0.0/schema.json','pageOrder':['sales_matrix'],'activePageName':'sales_matrix'})
save(Path('Sales.Report/definition/pages/sales_matrix/page.json'),{'$schema':'https://developer.microsoft.com/json-schemas/fabric/item/report/definition/page/2.1.0/schema.json','name':'sales_matrix','displayName':'Продажи по категориям и датам','displayOption':'FitToPage','height':720,'width':1280,'objects':{'background':[{'properties':{'color':color('#FFFFFF'),'transparency':literal('0D')}}]}})
objects={
 'columnHeaders':[{'properties':{'fontSize':literal('16D'),'backColor':color('#173B56'),'fontColor':color('#FFFFFF'),'bold':literal('true')}}],
 'rowHeaders':[{'properties':{'fontSize':literal('16D'),'fontColor':color('#173B56'),'stepped':literal('false')}}],
 'values':[{'properties':{'fontSize':literal('16D'),'fontColor':color('#173B56')}},{'selector':{'metadata':'Продажи.Сумма продаж'},'properties':{'backColor':{'solid':{'color':{'expr':field('Цвет ячейки','Measure')}}}}}],
 'grid':[{'properties':{'rowPadding':literal('18D'),'gridVertical':literal('true'),'gridHorizontal':literal('true')}}],
 'total':[{'properties':{'fontSize':literal('16D'),'fontColor':color('#173B56'),'backColor':color('#E4EFF7')}}],
 'columnWidth':[{'selector':{'metadata':'Продажи.Дата'},'properties':{'value':literal('165D')}}],
}
save(Path('Sales.Report/definition/pages/sales_matrix/visuals/matrix/visual.json'),{'$schema':'https://developer.microsoft.com/json-schemas/fabric/item/report/definition/visualContainer/2.14.0/schema.json','name':'matrix','position':{'x':64,'y':104,'z':0,'height':480,'width':1152,'tabOrder':0},'visual':{'visualType':'pivotTable','query':{'queryState':{'Rows':{'projections':[projection('Категория')]},'Columns':{'projections':[projection('Дата')]},'Values':{'projections':[projection('Сумма продаж','Measure')]}},'sortDefinition':{'sort':[{'field':field('Категория'),'direction':'Ascending'}]}},'objects':objects,'visualContainerObjects':{'title':[{'properties':{'show':literal('true'),'text':literal("'Сумма продаж по категориям | 1–4 декабря 2024'"),'fontSize':literal('23D'),'bold':literal('true'),'fontColor':color('#173B56')}}]},'drillFilterOtherVisuals':True}})
assert sum(r[2] for r in rows)==11000
print('PBIP generated; expected total 11000; dates sorted by negative YYYYMMDD')
